-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 29 Ara 2024, 12:05:43
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `budget_tracker`
--

DELIMITER $$
--
-- Yordamlar
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `calculate_monthly_balance` (IN `user_id` INT, IN `month_date` DATE)   BEGIN
    SELECT 
        COALESCE(i.total_income, 0) - COALESCE(e.total_expenses, 0) as balance,
        COALESCE(i.total_income, 0) as total_income,
        COALESCE(e.total_expenses, 0) as total_expenses
    FROM 
        (SELECT SUM(amount) as total_income 
         FROM income 
         WHERE user_id = user_id 
         AND DATE_FORMAT(date, '%Y-%m') = DATE_FORMAT(month_date, '%Y-%m')
        ) i,
        (SELECT SUM(amount) as total_expenses 
         FROM expenses 
         WHERE user_id = user_id 
         AND DATE_FORMAT(date, '%Y-%m') = DATE_FORMAT(month_date, '%Y-%m')
        ) e;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `budget_categories`
--

CREATE TABLE `budget_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `monthly_limit` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `expenses`
--

CREATE TABLE `expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `expenses`
--

INSERT INTO `expenses` (`id`, `user_id`, `amount`, `category`, `description`, `date`, `created_at`) VALUES
(1, 3, 1000.00, 'utilities', NULL, '0000-00-00', '2024-12-25 18:16:34'),
(3, 4, 10000.00, 'rent', NULL, '2024-12-29', '2024-12-29 10:11:11');

--
-- Tetikleyiciler `expenses`
--
DELIMITER $$
CREATE TRIGGER `after_expense_insert` AFTER INSERT ON `expenses` FOR EACH ROW BEGIN
    UPDATE savings_goals 
    SET current_amount = current_amount - NEW.amount
    WHERE user_id = NEW.user_id 
    AND current_amount >= NEW.amount;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `category_name`) VALUES
(1, 'Groceries'),
(2, 'Utilities'),
(3, 'Rent'),
(4, 'Transportation'),
(5, 'Healthcare'),
(6, 'Entertainment'),
(7, 'Education'),
(8, 'Shopping'),
(9, 'Other');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `income`
--

CREATE TABLE `income` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `source` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `income`
--

INSERT INTO `income` (`id`, `user_id`, `amount`, `source`, `description`, `date`, `created_at`) VALUES
(1, 3, 2500.00, 'salary', NULL, '2024-12-26', '2024-12-25 18:16:06');

--
-- Tetikleyiciler `income`
--
DELIMITER $$
CREATE TRIGGER `after_income_insert` AFTER INSERT ON `income` FOR EACH ROW BEGIN
    UPDATE savings_goals 
    SET current_amount = current_amount + NEW.amount
    WHERE user_id = NEW.user_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `income_sources`
--

CREATE TABLE `income_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `source_name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `income_sources`
--

INSERT INTO `income_sources` (`id`, `source_name`) VALUES
(1, 'Salary'),
(2, 'Freelance'),
(3, 'Investments'),
(4, 'Business'),
(5, 'Other');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `monthly_budgets`
--

CREATE TABLE `monthly_budgets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `month` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `monthly_expense_summary`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `monthly_expense_summary` (
`user_id` int(10) unsigned
,`month` varchar(7)
,`category` varchar(50)
,`total_amount` decimal(32,2)
);

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `monthly_income_summary`
-- (Asıl görünüm için aşağıya bakın)
--
CREATE TABLE `monthly_income_summary` (
`user_id` int(10) unsigned
,`month` varchar(7)
,`source` varchar(50)
,`total_amount` decimal(32,2)
);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `savings_goals`
--

CREATE TABLE `savings_goals` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `goal_name` varchar(100) NOT NULL,
  `target_amount` decimal(10,2) NOT NULL,
  `current_amount` decimal(10,2) DEFAULT 0.00,
  `deadline` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_login` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`, `last_login`, `reset_token`, `token_expiry`) VALUES
(6, 'test', '$2y$10$9pMm0awWZ7VMWnQGEZ.Cf.mYwLViCwDzvNrexFkNtvkNvXndizT5y', 'test@gmail.com', '2024-12-29 10:48:47', '2024-12-29 11:04:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Görünüm yapısı `monthly_expense_summary`
--
DROP TABLE IF EXISTS `monthly_expense_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `monthly_expense_summary`  AS SELECT `expenses`.`user_id` AS `user_id`, date_format(`expenses`.`date`,'%Y-%m') AS `month`, `expenses`.`category` AS `category`, sum(`expenses`.`amount`) AS `total_amount` FROM `expenses` GROUP BY `expenses`.`user_id`, date_format(`expenses`.`date`,'%Y-%m'), `expenses`.`category` ;

-- --------------------------------------------------------

--
-- Görünüm yapısı `monthly_income_summary`
--
DROP TABLE IF EXISTS `monthly_income_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `monthly_income_summary`  AS SELECT `income`.`user_id` AS `user_id`, date_format(`income`.`date`,'%Y-%m') AS `month`, `income`.`source` AS `source`, sum(`income`.`amount`) AS `total_amount` FROM `income` GROUP BY `income`.`user_id`, date_format(`income`.`date`,'%Y-%m'), `income`.`source` ;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `budget_categories`
--
ALTER TABLE `budget_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_category_per_user` (`user_id`,`category_name`);

--
-- Tablo için indeksler `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_expenses_user_date` (`user_id`,`date`),
  ADD KEY `idx_expenses_category` (`category`);

--
-- Tablo için indeksler `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Tablo için indeksler `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_income_user_date` (`user_id`,`date`),
  ADD KEY `idx_income_source` (`source`);

--
-- Tablo için indeksler `income_sources`
--
ALTER TABLE `income_sources`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `source_name` (`source_name`);

--
-- Tablo için indeksler `monthly_budgets`
--
ALTER TABLE `monthly_budgets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_budget_per_month` (`user_id`,`category_id`,`month`),
  ADD KEY `category_id` (`category_id`);

--
-- Tablo için indeksler `savings_goals`
--
ALTER TABLE `savings_goals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `budget_categories`
--
ALTER TABLE `budget_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Tablo için AUTO_INCREMENT değeri `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Tablo için AUTO_INCREMENT değeri `income`
--
ALTER TABLE `income`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `income_sources`
--
ALTER TABLE `income_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Tablo için AUTO_INCREMENT değeri `monthly_budgets`
--
ALTER TABLE `monthly_budgets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `savings_goals`
--
ALTER TABLE `savings_goals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
