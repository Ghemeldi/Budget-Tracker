// Form validation functions
function validateForm(formElement) {
    const amount = formElement.querySelector('input[name="amount"]');
    const category = formElement.querySelector('select[name="category"]');
    const date = formElement.querySelector('input[name="date"]');

    if (!amount.value || amount.value <= 0) {
        alert("Please enter a valid amount");
        amount.focus();
        return false;
    }

    if (!category.value) {
        alert("Please select a category");
        category.focus();
        return false;
    }

    if (!date.value) {
        alert("Please select a date");
        date.focus();
        return false;
    }

    return true;
}

// Display updates
function updateBalance(income, expenses) {
    const balance = income - expenses;
    document.getElementById('balance').innerHTML = 
        'Balance: $' + balance.toFixed(2);
}

// Form submission warning
function confirmSubmission() {
    return window.confirm("Are you sure you want to submit this entry?");
}

// Amount formatting
function formatAmount(amount) {
    return parseFloat(amount).toFixed(2);
}

// Date formatting
function formatDate(date) {
    let d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    let year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

// Show/hide elements
function toggleElement(elementId) {
    const element = document.getElementById(elementId);
    if (element.style.display === "none") {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
}