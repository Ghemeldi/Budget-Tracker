$(document).ready(function() {
    // Form submission handling
    $('#expense-form').submit(function(e) {
        if (!validateForm(this)) {
            e.preventDefault();
            return false;
        }
        return confirmSubmission();
    });

    $('#income-form').submit(function(e) {
        if (!validateForm(this)) {
            e.preventDefault();
            return false;
        }
        return confirmSubmission();
    });

    // Dynamic category selection
    $('.category-select').change(function() {
        if ($(this).val() === 'other') {
            $('#custom-category').show();
        } else {
            $('#custom-category').hide();
        }
    });

    // Delete entry confirmation
    $('.delete-btn').click(function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete this entry?')) {
            let entryId = $(this).data('id');
            $.ajax({
                url: 'includes/delete_entry.php',
                type: 'POST',
                data: { id: entryId },
                success: function(response) {
                    alert('Entry deleted successfully');
                    location.reload();
                },
                error: function() {
                    alert('Error deleting entry');
                }
            });
        }
    });

    // Real-time amount validation
    $('input[name="amount"]').keyup(function() {
        let amount = $(this).val();
        if (isNaN(amount) || amount <= 0) {
            $(this).addClass('error');
        } else {
            $(this).removeClass('error');
        }
    });

    // Date picker initialization
    $('input[type="date"]').each(function() {
        if (!$(this).val()) {
            $(this).val(formatDate(new Date()));
        }
    });

    // Summary chart toggle
    $('#toggle-chart').click(function() {
        $('#summary-chart').slideToggle();
    });

    // AJAX form submission
    $('.quick-add-form').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    alert('Entry added successfully');
                    location.reload();
                } else {
                    alert('Error: ' + response.message);
                }
            },
            error: function() {
                alert('Error adding entry');
            }
        });
    });

    // Category filter
    $('#category-filter').change(function() {
        let category = $(this).val();
        if (category === 'all') {
            $('.expense-row').show();
        } else {
            $('.expense-row').hide();
            $('.expense-row[data-category="' + category + '"]').show();
        }
    });

    // Sort table columns
    $('.sortable').click(function() {
        let table = $(this).parents('table').eq(0);
        let rows = table.find('tr:gt(0)').toArray().sort(comparator($(this).index()));
        this.asc = !this.asc;
        if (!this.asc) {
            rows = rows.reverse();
        }
        for (let i = 0; i < rows.length; i++) {
            table.append(rows[i]);
        }
    });
});

// Helper function for table sorting
function comparator(index) {
    return function(a, b) {
        let valA = getCellValue(a, index);
        let valB = getCellValue(b, index);
        return $.isNumeric(valA) && $.isNumeric(valB) ? 
            valA - valB : valA.toString().localeCompare(valB);
    };
}

function getCellValue(row, index) {
    return $(row).children('td').eq(index).text();
}