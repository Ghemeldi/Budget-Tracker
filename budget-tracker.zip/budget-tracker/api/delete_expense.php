<?php
require_once '../includes/login.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error) die($conn->connect_error);

    $expense_id = $conn->real_escape_string($_POST['id']);
    $user_id = $_SESSION['user_id'];

    // Only allow users to delete their own expenses
    $query = "DELETE FROM expenses WHERE id = '$expense_id' AND user_id = '$user_id'";
    $result = $conn->query($query);

    if ($result) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Error deleting expense']);
    }

    $conn->close();
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request']);
}
?>