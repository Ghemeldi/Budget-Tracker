<?php
// --------------------------------------------------------
// new_password.php
// --------------------------------------------------------

// 1. Include your database connection and helper functions
require_once '../includes/login.php';     // Adjust path if needed
require_once '../includes/functions.php'; // Adjust path if needed

// 2. Check for a token in the URL
if (!isset($_GET['token'])) {
    header('Location: ../index.php');
    exit();
}

// 3. Escape the token to prevent SQL injection
$token = $conn->real_escape_string($_GET['token']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password         = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 4. Check that both password fields match
    if ($password === $confirm_password) {
        // 5. Hash the new password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // 6. Update the user’s password, clearing the token and expiry
        $updateQuery = "
            UPDATE users
            SET password = '$hashed_password',
                reset_token = NULL,
                token_expiry = NULL
            WHERE reset_token = '$token'
        ";
        if ($conn->query($updateQuery) === TRUE) {
            if ($conn->affected_rows > 0) {
                echo "Password updated successfully. ";
                echo "<a href='../index.php'>Login here</a>";
                exit();
            } else {
                echo "No rows updated. The token is either invalid or expired.";
            }
        } else {
            // If the query itself fails, show DB error
            echo "Database error: " . $conn->error;
        }
    } else {
        echo "Passwords do not match. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Set New Password - Budget Tracker</title>
    <link rel="stylesheet" href="../css/style.css"><!-- adjust path if needed -->
</head>
<body>
<div class="container">
    <h1>Set New Password</h1>
    <form method="post">
        <div class="form-group">
            <label>New Password:</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>Confirm Password:</label>
            <input type="password" name="confirm_password" required>
        </div>
        <input type="submit" value="Update Password">
    </form>
</div>
</body>
</html>
