<!-- Main Menu Button -->
<div style="position: fixed; top: 10px; right: 10px;">
    <a href="/budget-tracker/index.php" style="text-decoration: none; background-color: #4CAF50; color: white; padding: 10px 20px; border-radius: 5px; font-family: Arial, sans-serif; font-size: 14px;">Main Menu</a>
</div>




<?php
require_once '../includes/login.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: ../index.php');
    exit();
}

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);

// Get monthly totals
$month = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Financial Reports - Budget Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
    <div id="reports-page">
        <h1>Financial Reports</h1>

        <div id="date-select">
            <form method="get">
                <label>Select Month: </label>
                <input type="month" name="month" value="<?php echo $month; ?>" onchange="this.form.submit()">
            </form>
        </div>

        <div id="monthly-summary">
            <?php
            // Get monthly income
            $query = "SELECT SUM(amount) as total FROM income WHERE user_id = " . $_SESSION['user_id'] . 
                    " AND DATE_FORMAT(date, '%Y-%m') = '$month'";
            $result = $conn->query($query);
            if (!$result) die($conn->error);
            $row = $result->fetch_array(MYSQLI_ASSOC);
            $monthly_income = $row['total'] ?? 0;

            // Get monthly expenses
            $query = "SELECT category, SUM(amount) as total FROM expenses WHERE user_id = " . 
                    $_SESSION['user_id'] . " AND DATE_FORMAT(date, '%Y-%m') = '$month' GROUP BY category";
            $result = $conn->query($query);
            if (!$result) die($conn->error);

            echo "<h2>Monthly Summary for " . date('F Y', strtotime($month)) . "</h2>";
            echo "<p>Total Income: $" . number_format($monthly_income, 2) . "</p>";
            
            echo "<h3>Expenses by Category:</h3>";
            echo "<table border='1'>";
            echo "<tr><th>Category</th><th>Amount</th><th>% of Income</th></tr>";
            
            $total_expenses = 0;
            while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                $percentage = $monthly_income > 0 ? ($row['total'] / $monthly_income * 100) : 0;
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                echo "<td>$" . number_format($row['total'], 2) . "</td>";
                echo "<td>" . number_format($percentage, 1) . "%</td>";
                echo "</tr>";
                $total_expenses += $row['total'];
            }
            echo "</table>";

            $savings = $monthly_income - $total_expenses;
            echo "<p>Total Expenses: $" . number_format($total_expenses, 2) . "</p>";
            echo "<p>Savings: $" . number_format($savings, 2) . "</p>";
            ?>
        </div>

        <div id="export-section">
            <button onclick="exportReport()">Export Report</button>
        </div>
    </div>

    <script>
    function exportReport() {
        window.print();
    }
    </script>
</body>
</html>