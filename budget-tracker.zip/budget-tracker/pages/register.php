<!-- Main Menu Button -->
<div style="position: fixed; top: 10px; right: 10px;">
    <a href="/budget-tracker/index.php" style="text-decoration: none; background-color: #4CAF50; color: white; padding: 10px 20px; border-radius: 5px; font-family: Arial, sans-serif; font-size: 14px;">Main Menu</a>
</div>



<?php
require_once '../includes/login.php';
require_once '../includes/functions.php';

// If user is already logged in, redirect to index
if (isset($_SESSION['username'])) {
   header('Location: ../index.php');
   exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   $username = $conn->real_escape_string($_POST['username']);
   $password = $_POST['password'];
   $confirm_password = $_POST['confirm_password'];
   $email = $conn->real_escape_string($_POST['email']);

   // Validate input
   if (empty($username) || empty($password) || empty($confirm_password) || empty($email)) {
       $error = "All fields are required";
   } 
   elseif ($password !== $confirm_password) {
       $error = "Passwords do not match";
   }
   elseif (strlen($password) < 8) {
       $error = "Password must be at least 8 characters long";
   }
   elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $error = "Invalid email format";
   }
   else {
       // Check if username already exists
       $stmt = $conn->prepare('SELECT id FROM users WHERE username = ?');
       $stmt->bind_param('s', $username);
       $stmt->execute();
       $result = $stmt->get_result();
       
       if ($result->num_rows > 0) {
           $error = "Username already exists";
       } else {
           // Check if email already exists
           $stmt = $conn->prepare('SELECT id FROM users WHERE email = ?');
           $stmt->bind_param('s', $email);
           $stmt->execute();
           $result = $stmt->get_result();
           
           if ($result->num_rows > 0) {
               $error = "Email already registered";
           } else {
               // Hash password
               $hashed_password = password_hash($password, PASSWORD_DEFAULT);
               
               // Insert new user
               $stmt = $conn->prepare('INSERT INTO users (username, password, email) VALUES (?, ?, ?)');
               $stmt->bind_param('sss', $username, $hashed_password, $email);
               
               if ($stmt->execute()) {
                   $success = "Registration successful! You can now login.";
                   // Redirect after 2 seconds
                   header("refresh:2;url=../index.php");
               } else {
                   $error = "Error creating account. Please try again.";
               }
           }
       }
   }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
   <title>Register - Budget Tracker</title>
   <link rel="stylesheet" href="../css/style.css">
   <link rel="stylesheet" href="../css/layout.css">
   <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
   <script>
   $(document).ready(function() {
       // Real-time password match validation
       $('#confirm_password').on('keyup', function() {
           if ($('#password').val() == $('#confirm_password').val()) {
               $('#password_match').html('Passwords match').css('color', 'green');
           } else {
               $('#password_match').html('Passwords do not match').css('color', 'red');
           }
       });

       // Form validation
       $('form').submit(function(e) {
           let password = $('#password').val();
           let hasNumber = /\d/.test(password);
           let hasLetter = /[a-zA-Z]/.test(password);
           
           if (password.length < 8 || !hasNumber || !hasLetter) {
               alert('Password must be at least 8 characters long and contain both letters and numbers');
               e.preventDefault();
               return false;
           }
           return true;
       });
   });
   </script>
</head>
<body>
   <div class="container">
       <div class="form-container">
           <h1>Register for Budget Tracker</h1>
           
           <?php if ($error): ?>
               <div class="error"><?php echo htmlspecialchars($error); ?></div>
           <?php endif; ?>
           
           <?php if ($success): ?>
               <div class="success"><?php echo htmlspecialchars($success); ?></div>
           <?php endif; ?>

           <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
               <div class="form-group">
                   <label for="username">Username:</label>
                   <input type="text" id="username" name="username" 
                          value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                          required pattern="[A-Za-z0-9_]{3,}"
                          title="Username must be at least 3 characters long and can only contain letters, numbers, and underscores">
               </div>

               <div class="form-group">
                   <label for="email">Email:</label>
                   <input type="email" id="email" name="email"
                          value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>"
                          required>
               </div>

               <div class="form-group">
                   <label for="password">Password:</label>
                   <input type="password" id="password" name="password" required
                          pattern="(?=.*\d)(?=.*[a-zA-Z]).{8,}"
                          title="Must contain at least one number and one letter, and at least 8 or more characters">
               </div>

               <div class="form-group">
                   <label for="confirm_password">Confirm Password:</label>
                   <input type="password" id="confirm_password" name="confirm_password" required>
                   <span id="password_match"></span>
               </div>

               <div class="form-group">
                   <input type="submit" value="Register">
               </div>
           </form>

           <p>Already have an account? <a href="../index.php">Login here</a></p>
       </div>
   </div>
</body>
</html>