<?php
// --------------------------------------------------------
// reset_password.php
// --------------------------------------------------------

// 1. Include your database connection and functions.
require_once '../includes/login.php';      // Adjust path if needed
require_once '../includes/functions.php';  // Adjust path if needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 2. Sanitize the user input
    $email = $conn->real_escape_string($_POST['email']);

    // 3. Check if that email exists in the DB
    $query  = "SELECT id FROM users WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // 4. Generate a token and set expiry for 1 hour from now
        $token  = bin2hex(random_bytes(32)); // 64-char hex string
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // 5. Store the token and expiry in the database
        $updateQuery = "
            UPDATE users
            SET reset_token  = '$token',
                token_expiry = '$expiry'
            WHERE email = '$email'
        ";
        $conn->query($updateQuery);

        // 6. (Normally send email). For demo, just display the reset link:
        echo "<p>Password reset link (normally emailed):</p>";
        echo "<a href='new_password.php?token=$token'>Reset Password</a>";
    } else {
        // For security, don’t reveal if the email isn’t in your system
        echo "If an account exists with that email, you will receive reset instructions.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - Budget Tracker</title>
    <link rel="stylesheet" href="../css/style.css"><!-- adjust path if needed -->
</head>
<body>
<div class="container">
    <h1>Reset Password</h1>
    <form method="post">
        <p>Enter your email address to receive password reset instructions:</p>
        <input type="email" name="email" required>
        <input type="submit" value="Request Reset">
    </form>
    <p><a href="../index.php">Back to Login</a></p><!-- Adjust link if needed -->
</div>
</body>
</html>
