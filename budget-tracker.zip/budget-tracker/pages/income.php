<!-- Main Menu Button -->
<div style="position: fixed; top: 10px; right: 10px;">
    <a href="/budget-tracker/index.php" style="text-decoration: none; background-color: #4CAF50; color: white; padding: 10px 20px; border-radius: 5px; font-family: Arial, sans-serif; font-size: 14px;">Main Menu</a>
</div>


<?php
require_once '../includes/login.php';
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = new mysqli($hn, $un, $pw, $db);
    if ($conn->connect_error) die($conn->connect_error);

    $amount = $conn->real_escape_string($_POST['amount']);
    $source = $conn->real_escape_string($_POST['source']);
    $date = $conn->real_escape_string($_POST['date']);
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO income (user_id, amount, source, date) VALUES ('$user_id', '$amount', '$source', '$date')";
    $result = $conn->query($query);
    if (!$result) {
        echo "<script>alert('Error adding income');</script>";
    } else {
        echo "<script>alert('Income added successfully');</script>";
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Income - Budget Tracker</title>
    <link rel="stylesheet" href="../css/style.css">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
    <div id="income-page">
        <h1>Manage Income</h1>
        
        <div id="add-income">
            <h2>Add New Income</h2>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <pre>
                Amount: <input type="number" name="amount" step="0.01" required>
                Source: <select name="source" required>
                          <option value="salary">Salary</option>
                          <option value="freelance">Freelance</option>
                          <option value="other">Other</option>
                        </select>
                Date:   <input type="date" name="date" required>
                        <input type="submit" value="Add Income">
                </pre>
            </form>
        </div>

        <div id="income-list">
            <h2>Recent Income</h2>
            <?php
            $conn = new mysqli($hn, $un, $pw, $db);
            if ($conn->connect_error) die($conn->connect_error);

            $query = "SELECT * FROM income WHERE user_id = " . $_SESSION['user_id'] . 
                    " ORDER BY date DESC LIMIT 10";
            $result = $conn->query($query);
            if (!$result) die($conn->error);

            echo "<table border='1'>";
            echo "<tr><th>Date</th><th>Source</th><th>Amount</th><th>Actions</th></tr>";
            
            while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['source']) . "</td>";
                echo "<td>$" . number_format($row['amount'], 2) . "</td>";
                echo "<td><button onclick='deleteIncome(" . $row['id'] . ")'>Delete</button></td>";
                echo "</tr>";
            }
            echo "</table>";
            ?>
        </div>
    </div>

    <script>
    function deleteIncome(id) {
        if (confirm('Are you sure you want to delete this income entry?')) {
            $.ajax({
                url: '../api/delete_income.php',
                type: 'POST',
                data: {id: id},
                success: function(response) {
                    alert('Income entry deleted successfully');
                    location.reload();
                },
                error: function() {
                    alert('Error deleting income entry');
                }
            });
        }
    }
    </script>
</body>
</html>