<?php
require_once 'includes/login.php';
session_start();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8">
    <title>Budget Tracker</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/layout.css">
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
    <?php
    if (!isset($_SESSION['username'])) {
        // Your login form HTML
    ?>
        <div id="login-section">
    <h1>Budget Tracker</h1>
    <form method="post" action="<?php $_SERVER['PHP_SELF'] ?>">
        <pre>
        Username: <input type="text" name="username">
        Password: <input type="password" name="password">
            <input type="submit" value="Login">
        </pre>
    </form>
    
    <p>New user? <a href="pages/register.php">Register here</a></p>
    <p>Forgot your password? <a href="pages/reset_password.php">Reset it here</a></p>
</div>
    <?php
    } else {
    ?>
        <div class="container">
            <div id="dashboard">
                <header>
                    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
                    <nav>
                        <ul>
                            <li><a href="pages/expenses.php">Expenses</a></li>
                            <li><a href="pages/income.php">Income</a></li>
                            <li><a href="pages/reports.php">Reports</a></li>
                            <li><a href="includes/logout.php">Logout</a></li>
                        </ul>
                    </nav>
                </header>

                <div id="content-sections">
                    <div id="summary">
                        <h2>Financial Summary</h2>
                        <?php
                        // Database connection
                        require_once 'includes/functions.php';
                        $conn = new mysqli($hn, $un, $pw, $db);
                        if ($conn->connect_error) die($conn->connect_error);

                        // Get total income
                        $query = "SELECT SUM(amount) as total_income FROM income WHERE user_id = " . 
                                $_SESSION['user_id'];
                        $result = $conn->query($query);
                        if (!$result) die($conn->error);
                        $row = $result->fetch_array(MYSQLI_ASSOC);
                        $total_income = $row['total_income'] ?? 0;

                        // Get total expenses
                        $query = "SELECT SUM(amount) as total_expenses FROM expenses WHERE user_id = " . 
                                $_SESSION['user_id'];
                        $result = $conn->query($query);
                        if (!$result) die($conn->error);
                        $row = $result->fetch_array(MYSQLI_ASSOC);
                        $total_expenses = $row['total_expenses'] ?? 0;
                        ?>

                        <div class="summary-box">
                            <p>Total Income: $<?php echo number_format($total_income, 2); ?></p>
                            <p>Total Expenses: $<?php echo number_format($total_expenses, 2); ?></p>
                            <p>Balance: $<?php echo number_format($total_income - $total_expenses, 2); ?></p>
                        </div>
                    </div>

                                    <div id="quick-add">
                    <h2>Quick Add</h2>
                    <form method="post" action="pages/expenses.php" id="expense-form">
                        <label>Add Expense:</label>
                        <input type="number" name="amount" step="0.01" required>
                        <select name="category" required>
                            <option value="groceries">Groceries</option>
                            <option value="utilities">Utilities</option>
                            <option value="rent">Rent</option>
                            <option value="other">Other</option>
                        </select>
                        <input type="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                        <input type="submit" value="Add Expense">
                    </form>
                </div>

        <script>
        $(document).ready(function() {
            $("#expense-form").submit(function(e) {
                if (!confirm('Are you sure you want to add this expense?')) {
                    e.preventDefault();
                }
            });
        });
        </script>
    <?php
    }
    ?>
</body>
</html>
