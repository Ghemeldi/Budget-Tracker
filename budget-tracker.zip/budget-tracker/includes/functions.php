<?php
function sanitizeString($var)
{
    if (get_magic_quotes_gpc())
        $var = stripslashes($var);
    $var = strip_tags($var);
    $var = htmlentities($var);
    return $var;
}

function validatePassword($password) {
    // Password must be at least 8 characters and contain numbers and letters
    return strlen($password) >= 8 && 
           preg_match("/[A-Za-z]/", $password) && 
           preg_match("/[0-9]/", $password);
}

function getMonthlyExpenses($conn, $userId, $month) {
    $query = "SELECT category, SUM(amount) as total 
              FROM expenses 
              WHERE user_id = '$userId' 
              AND MONTH(date) = MONTH('$month') 
              AND YEAR(date) = YEAR('$month') 
              GROUP BY category";
    
    $result = $conn->query($query);
    if (!$result) die($conn->error);
    
    $expenses = array();
    while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
        $expenses[$row['category']] = $row['total'];
    }
    return $expenses;
}

function getMonthlyIncome($conn, $userId, $month) {
    $query = "SELECT SUM(amount) as total 
              FROM income 
              WHERE user_id = '$userId' 
              AND MONTH(date) = MONTH('$month') 
              AND YEAR(date) = YEAR('$month')";
    
    $result = $conn->query($query);
    if (!$result) die($conn->error);
    
    $row = $result->fetch_array(MYSQLI_ASSOC);
    return $row['total'] ?? 0;
}

function calculateBalance($income, $expenses) {
    $totalExpenses = 0;
    foreach ($expenses as $amount) {
        $totalExpenses += $amount;
    }
    return $income - $totalExpenses;
}

function displayError($error) {
    echo "<div class='error'>Error: " . htmlspecialchars($error) . "</div>";
}

function displaySuccess($message) {
    echo "<div class='success'>" . htmlspecialchars($message) . "</div>";
}

function checkLoggedIn() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit();
    }
}

function createTable($conn, $query) {
    $result = $conn->query($query);
    if (!$result) die($conn->error);

    $rows = $result->num_rows;
    $result->data_seek(0);
    $first = $result->fetch_assoc();
    
    echo "<table border='1'><tr>";
    foreach ($first as $key => $value) {
        echo "<th>" . htmlspecialchars($key) . "</th>";
    }
    echo "</tr>";

    $result->data_seek(0);
    for ($j = 0; $j < $rows; ++$j) {
        $result->data_seek($j);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        echo "<tr>";
        foreach ($row as $value) {
            echo "<td>" . htmlspecialchars($value) . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}

function addExpense($conn, $userId, $amount, $category, $date) {
    $stmt = $conn->prepare('INSERT INTO expenses (user_id, amount, category, date) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('idss', $userId, $amount, $category, $date);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function addIncome($conn, $userId, $amount, $source, $date) {
    $stmt = $conn->prepare('INSERT INTO income (user_id, amount, source, date) VALUES (?, ?, ?, ?)');
    $stmt->bind_param('idss', $userId, $amount, $source, $date);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function deleteExpense($conn, $expenseId, $userId) {
    $stmt = $conn->prepare('DELETE FROM expenses WHERE id = ? AND user_id = ?');
    $stmt->bind_param('ii', $expenseId, $userId);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

function deleteIncome($conn, $incomeId, $userId) {
    $stmt = $conn->prepare('DELETE FROM income WHERE id = ? AND user_id = ?');
    $stmt->bind_param('ii', $incomeId, $userId);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}
?>