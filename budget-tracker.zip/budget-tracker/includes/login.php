<?php
$hn = 'localhost';
$db = 'budget_tracker';
$un = 'root';  // Replace with your database username
$pw = '';  // Replace with your database password

$conn = new mysqli($hn, $un, $pw, $db);
if ($conn->connect_error) die($conn->connect_error);


if (isset($_POST['username']) && isset($_POST['password'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE username='$username'";
    $result = $conn->query($query);
    
    if (!$result) die($conn->error);
    elseif ($result->num_rows) {
        $row = $result->fetch_array(MYSQLI_ASSOC);
        $result->close();
        
        if (password_verify($password, $row['password'])) {
            session_start();
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            
            // Check if "remember me" was checked
            if (isset($_POST['remember'])) {
                setcookie('username', $username, time() + 60*60*24*30);
                setcookie('password', $password, time() + 60*60*24*30);
            }
            
            // Redirect to dashboard
            header('Location: index.php');
            exit;
        } else {
            echo "<div class='error'>Invalid username/password combination</div>";
        }
    } else {
        echo "<div class='error'>Invalid username/password combination</div>";
    }
}

function createUser($conn, $username, $password, $email) {
    // Check if username already exists
    $stmt = $conn->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return "Username already exists";
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $conn->prepare('INSERT INTO users (username, password, email) VALUES (?, ?, ?)');
    $stmt->bind_param('sss', $username, $hashed_password, $email);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return "Error creating user";
    }
}

function changePassword($conn, $userId, $oldPassword, $newPassword) {
    // Verify old password
    $stmt = $conn->prepare('SELECT password FROM users WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!password_verify($oldPassword, $user['password'])) {
        return "Current password is incorrect";
    }
    
    // Update password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
    $stmt->bind_param('si', $hashedPassword, $userId);
    
    if ($stmt->execute()) {
        return true;
    } else {
        return "Error updating password";
    }
}

function logout() {
    session_start();
    session_destroy();
    
    // Remove cookies if they exist
    if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
        setcookie('username', '', time() - 3600);
        setcookie('password', '', time() - 3600);
    }
    
    header('Location: index.php');
    exit;
}
?>